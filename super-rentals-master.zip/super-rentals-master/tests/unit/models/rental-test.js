import { moduleForModel, test } from 'ember-qunit';

moduleForModel('rental', 'Unit | Model | rental', {
  // Specify the other units that are required for this test.
  needs: []
});

test('it exists', function(assert) {
  let model = this.subject();
  // let store = this.get('store')();
  assert.ok(!!model);
});
