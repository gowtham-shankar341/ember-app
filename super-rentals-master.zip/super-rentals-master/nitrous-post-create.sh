#!/bin/bash
npm install -g bower
cd code/super-rentals
npm install
bower install
