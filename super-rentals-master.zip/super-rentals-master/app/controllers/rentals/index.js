import RentalsController from '../rentals';

export default RentalsController;
